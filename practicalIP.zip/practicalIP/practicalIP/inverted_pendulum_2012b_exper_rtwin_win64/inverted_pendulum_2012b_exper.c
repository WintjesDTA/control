/*
 * inverted_pendulum_2012b_exper.c
 *
 * Code generation for model "inverted_pendulum_2012b_exper".
 *
 * Model version              : 1.60
 * Simulink Coder version : 8.3 (R2012b) 20-Jul-2012
 * C source code generated on : Wed May 24 16:26:56 2017
 *
 * Target selection: rtwin.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include "inverted_pendulum_2012b_exper.h"
#include "inverted_pendulum_2012b_exper_private.h"
#include "inverted_pendulum_2012b_exper_dt.h"

/* options for Real-Time Windows Target board 0 */
static double RTWinBoardOptions0[] = {
  1.0,
  0.0,
  0.0,
  0.0,
  0.0,
  0.0,
};

/* list of Real-Time Windows Target timers */
const int RTWinTimerCount = 1;
const double RTWinTimers[2] = {
  0.005, 0.0,
};

/* list of Real-Time Windows Target boards */
const int RTWinBoardCount = 1;
RTWINBOARD RTWinBoards[1] = {
  { "National_Instruments/PCI-6014", 1U, 6, RTWinBoardOptions0 },
};

/* Block signals (auto storage) */
BlockIO_inverted_pendulum_2012b_exper inverted_pendulum_2012b_exper_B;

/* Block states (auto storage) */
D_Work_inverted_pendulum_2012b_exper inverted_pendulum_2012b_exper_DWork;

/* Real-time model */
RT_MODEL_inverted_pendulum_2012b_exper inverted_pendulum_2012b_exper_M_;
RT_MODEL_inverted_pendulum_2012b_exper *const inverted_pendulum_2012b_exper_M =
  &inverted_pendulum_2012b_exper_M_;
static void rate_scheduler(void);

/*
 *   This function updates active task flag for each subrate.
 * The function is called at model base rate, hence the
 * generated code self-manages all its subrates.
 */
static void rate_scheduler(void)
{
  /* Compute which subrates run during the next base time step.  Subrates
   * are an integer multiple of the base rate counter.  Therefore, the subtask
   * counter is reset when it reaches its limit (zero means run).
   */
  (inverted_pendulum_2012b_exper_M->Timing.TaskCounters.TID[1])++;
  if ((inverted_pendulum_2012b_exper_M->Timing.TaskCounters.TID[1]) > 49) {/* Sample time: [0.25s, 0.0s] */
    inverted_pendulum_2012b_exper_M->Timing.TaskCounters.TID[1] = 0;
  }

  inverted_pendulum_2012b_exper_M->Timing.sampleHits[1] =
    (inverted_pendulum_2012b_exper_M->Timing.TaskCounters.TID[1] == 0);
}

/* Model output function */
void inverted_pendulum_2012b_exper_output(void)
{
  /* local block i/o variables */
  real_T rtb_Gain[2];
  real_T rtb_Gain_h;
  real_T rtb_Add2;
  real_T rtb_Add1;
  real_T rtb_Gain_0;
  real_T tmp;

  /* S-Function Block: <S1>/Analog Input */
  {
    ANALOGIOPARM parm;
    parm.mode = (RANGEMODE)
      inverted_pendulum_2012b_exper_P.AnalogInput_RangeMode;
    parm.rangeidx = inverted_pendulum_2012b_exper_P.AnalogInput_VoltRange;
    RTBIO_DriverIO(0, ANALOGINPUT, IOREAD, 2,
                   inverted_pendulum_2012b_exper_P.AnalogInput_Channels,
                   rtb_Gain, &parm);
  }

  /* Sum: '<S1>/Add2' incorporates:
   *  Constant: '<S1>/Offset_x (volts)'
   */
  rtb_Add2 = inverted_pendulum_2012b_exper_P.Offset_xvolts_Value + rtb_Gain[0];

  /* Gain: '<S1>/Convertion actor' */
  inverted_pendulum_2012b_exper_B.Convertionactor =
    inverted_pendulum_2012b_exper_P.Convertionactor_Gain * rtb_Add2;

  /* Sum: '<S1>/Add1' incorporates:
   *  Constant: '<S1>/Offset_alfa (volt)'
   */
  rtb_Add1 = rtb_Gain[1] + inverted_pendulum_2012b_exper_P.Offset_alfavolt_Value;

  /* Gain: '<S1>/Convertion ' */
  inverted_pendulum_2012b_exper_B.Convertion =
    inverted_pendulum_2012b_exper_P.Convertion_Gain * rtb_Add1;

  /* Gain: '<Root>/Gain' */
  rtb_Gain[0] = inverted_pendulum_2012b_exper_P.Gain_Gain *
    inverted_pendulum_2012b_exper_B.Convertionactor;
  rtb_Gain[1] = inverted_pendulum_2012b_exper_P.Gain_Gain *
    inverted_pendulum_2012b_exper_B.Convertion;

  /* Gain: '<Root>/Gain1' incorporates:
   *  Delay: '<Root>/Delay'
   *  Sum: '<Root>/Sum'
   */
  inverted_pendulum_2012b_exper_B.Gain1[0] = (rtb_Gain[0] +
    inverted_pendulum_2012b_exper_DWork.Delay_DSTATE[0]) *
    inverted_pendulum_2012b_exper_P.Gain1_Gain;
  inverted_pendulum_2012b_exper_B.Gain1[1] = (rtb_Gain[1] +
    inverted_pendulum_2012b_exper_DWork.Delay_DSTATE[1]) *
    inverted_pendulum_2012b_exper_P.Gain1_Gain;

  /* Gain: '<Root>/Gain3' incorporates:
   *  Delay: '<Root>/Delay1'
   *  Sum: '<Root>/Sum2'
   */
  inverted_pendulum_2012b_exper_B.Gain3[0] =
    (inverted_pendulum_2012b_exper_B.Gain1[0] -
     inverted_pendulum_2012b_exper_DWork.Delay1_DSTATE[0]) *
    inverted_pendulum_2012b_exper_P.Gain3_Gain;
  inverted_pendulum_2012b_exper_B.Gain3[1] =
    (inverted_pendulum_2012b_exper_B.Gain1[1] -
     inverted_pendulum_2012b_exper_DWork.Delay1_DSTATE[1]) *
    inverted_pendulum_2012b_exper_P.Gain3_Gain;

  /* Step: '<Root>/Step' */
  if (inverted_pendulum_2012b_exper_M->Timing.t[0] <
      inverted_pendulum_2012b_exper_P.Step_Time) {
    rtb_Gain_h = inverted_pendulum_2012b_exper_P.Step_Y0;
  } else {
    rtb_Gain_h = inverted_pendulum_2012b_exper_P.Step_YFinal;
  }

  /* End of Step: '<Root>/Step' */

  /* Sin: '<Root>/Sine Wave' */
  if (inverted_pendulum_2012b_exper_DWork.systemEnable != 0) {
    inverted_pendulum_2012b_exper_DWork.lastSin = sin
      (inverted_pendulum_2012b_exper_P.SineWave_Freq *
       inverted_pendulum_2012b_exper_M->Timing.t[0]);
    inverted_pendulum_2012b_exper_DWork.lastCos = cos
      (inverted_pendulum_2012b_exper_P.SineWave_Freq *
       inverted_pendulum_2012b_exper_M->Timing.t[0]);
    inverted_pendulum_2012b_exper_DWork.systemEnable = 0;
  }

  /* ManualSwitch: '<Root>/Manual Switch' incorporates:
   *  Sin: '<Root>/Sine Wave'
   */
  if (inverted_pendulum_2012b_exper_P.ManualSwitch_CurrentSetting != 1) {
    rtb_Gain_h = ((inverted_pendulum_2012b_exper_DWork.lastSin *
                   inverted_pendulum_2012b_exper_P.SineWave_PCos +
                   inverted_pendulum_2012b_exper_DWork.lastCos *
                   inverted_pendulum_2012b_exper_P.SineWave_PSin) *
                  inverted_pendulum_2012b_exper_P.SineWave_HCos +
                  (inverted_pendulum_2012b_exper_DWork.lastCos *
                   inverted_pendulum_2012b_exper_P.SineWave_PCos -
                   inverted_pendulum_2012b_exper_DWork.lastSin *
                   inverted_pendulum_2012b_exper_P.SineWave_PSin) *
                  inverted_pendulum_2012b_exper_P.SineWave_Hsin) *
      inverted_pendulum_2012b_exper_P.SineWave_Amp +
      inverted_pendulum_2012b_exper_P.SineWave_Bias;
  }

  /* End of ManualSwitch: '<Root>/Manual Switch' */

  /* ManualSwitch: '<Root>/Manual Switch1' incorporates:
   *  Constant: '<Root>/Off1'
   */
  if (inverted_pendulum_2012b_exper_P.ManualSwitch1_CurrentSetting == 1) {
    rtb_Gain_h = inverted_pendulum_2012b_exper_P.Off1_Value;
  }

  /* End of ManualSwitch: '<Root>/Manual Switch1' */

  /* Sum: '<Root>/Sum1' */
  rtb_Gain_h = inverted_pendulum_2012b_exper_B.Gain3[1] - rtb_Gain_h;

  /* Gain: '<Root>/Gain2' incorporates:
   *  SignalConversion: '<Root>/TmpSignal ConversionAtGain2Inport1'
   */
  rtb_Gain_0 = ((inverted_pendulum_2012b_exper_P.Gain2_Gain[0] *
                 inverted_pendulum_2012b_exper_B.Convertionactor +
                 inverted_pendulum_2012b_exper_P.Gain2_Gain[1] *
                 inverted_pendulum_2012b_exper_B.Convertion) +
                inverted_pendulum_2012b_exper_P.Gain2_Gain[2] *
                inverted_pendulum_2012b_exper_B.Gain3[0]) +
    inverted_pendulum_2012b_exper_P.Gain2_Gain[3] * rtb_Gain_h;

  /* ManualSwitch: '<Root>/Switch  ' incorporates:
   *  Constant: '<Root>/Off'
   *  Gain: '<Root>/Gain2'
   */
  if (inverted_pendulum_2012b_exper_P.Switch_CurrentSetting == 1) {
    rtb_Gain_h = rtb_Gain_0;
  } else {
    rtb_Gain_h = inverted_pendulum_2012b_exper_P.Off_Value;
  }

  /* End of ManualSwitch: '<Root>/Switch  ' */

  /* Saturate: '<S2>/-5v to 5v' */
  if (rtb_Gain_h >= inverted_pendulum_2012b_exper_P.uvto5v_UpperSat) {
    tmp = inverted_pendulum_2012b_exper_P.uvto5v_UpperSat;
  } else if (rtb_Gain_h <= inverted_pendulum_2012b_exper_P.uvto5v_LowerSat) {
    tmp = inverted_pendulum_2012b_exper_P.uvto5v_LowerSat;
  } else {
    tmp = rtb_Gain_h;
  }

  /* Gain: '<S2>/Gain' incorporates:
   *  Saturate: '<S2>/-5v to 5v'
   */
  rtb_Gain_h = inverted_pendulum_2012b_exper_P.Gain_Gain_k * tmp;

  /* S-Function Block: <S2>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE)
        inverted_pendulum_2012b_exper_P.AnalogOutput_RangeMode;
      parm.rangeidx = inverted_pendulum_2012b_exper_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &inverted_pendulum_2012b_exper_P.AnalogOutput_Channels,
                     &rtb_Gain_h, &parm);
    }
  }

  /* Saturate: '<Root>/Saturation' incorporates:
   *  Gain: '<Root>/Gain2'
   */
  if (rtb_Gain_0 >= inverted_pendulum_2012b_exper_P.Saturation_UpperSat) {
    inverted_pendulum_2012b_exper_B.Saturation =
      inverted_pendulum_2012b_exper_P.Saturation_UpperSat;
  } else if (rtb_Gain_0 <= inverted_pendulum_2012b_exper_P.Saturation_LowerSat)
  {
    inverted_pendulum_2012b_exper_B.Saturation =
      inverted_pendulum_2012b_exper_P.Saturation_LowerSat;
  } else {
    inverted_pendulum_2012b_exper_B.Saturation = rtb_Gain_0;
  }

  /* End of Saturate: '<Root>/Saturation' */

  /* RateTransition: '<S1>/Rate Transition1' */
  if (inverted_pendulum_2012b_exper_M->Timing.TaskCounters.TID[1] == 0) {
    inverted_pendulum_2012b_exper_B.RateTransition1[0] =
      inverted_pendulum_2012b_exper_B.Convertionactor;
    inverted_pendulum_2012b_exper_B.RateTransition1[1] =
      inverted_pendulum_2012b_exper_B.Convertion;

    /* Gain: '<S3>/Gain' */
    inverted_pendulum_2012b_exper_B.Gain =
      inverted_pendulum_2012b_exper_P.Gain_Gain_b *
      inverted_pendulum_2012b_exper_B.RateTransition1[1];

    /* RateTransition: '<S1>/Rate Transition' */
    inverted_pendulum_2012b_exper_B.RateTransition[0] = rtb_Add2;
    inverted_pendulum_2012b_exper_B.RateTransition[1] = rtb_Add1;
  }

  /* End of RateTransition: '<S1>/Rate Transition1' */
}

/* Model update function */
void inverted_pendulum_2012b_exper_update(void)
{
  real_T HoldSine;

  /* Update for Delay: '<Root>/Delay' */
  inverted_pendulum_2012b_exper_DWork.Delay_DSTATE[0] =
    inverted_pendulum_2012b_exper_B.Gain1[0];
  inverted_pendulum_2012b_exper_DWork.Delay_DSTATE[1] =
    inverted_pendulum_2012b_exper_B.Gain1[1];

  /* Update for Delay: '<Root>/Delay1' */
  inverted_pendulum_2012b_exper_DWork.Delay1_DSTATE[0] =
    inverted_pendulum_2012b_exper_B.Gain1[0];
  inverted_pendulum_2012b_exper_DWork.Delay1_DSTATE[1] =
    inverted_pendulum_2012b_exper_B.Gain1[1];

  /* Update for Sin: '<Root>/Sine Wave' */
  HoldSine = inverted_pendulum_2012b_exper_DWork.lastSin;
  inverted_pendulum_2012b_exper_DWork.lastSin =
    inverted_pendulum_2012b_exper_DWork.lastSin *
    inverted_pendulum_2012b_exper_P.SineWave_HCos +
    inverted_pendulum_2012b_exper_DWork.lastCos *
    inverted_pendulum_2012b_exper_P.SineWave_Hsin;
  inverted_pendulum_2012b_exper_DWork.lastCos =
    inverted_pendulum_2012b_exper_DWork.lastCos *
    inverted_pendulum_2012b_exper_P.SineWave_HCos - HoldSine *
    inverted_pendulum_2012b_exper_P.SineWave_Hsin;

  /* Update absolute time for base rate */
  /* The "clockTick0" counts the number of times the code of this task has
   * been executed. The absolute time is the multiplication of "clockTick0"
   * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
   * overflow during the application lifespan selected.
   * Timer of this task consists of two 32 bit unsigned integers.
   * The two integers represent the low bits Timing.clockTick0 and the high bits
   * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
   */
  if (!(++inverted_pendulum_2012b_exper_M->Timing.clockTick0)) {
    ++inverted_pendulum_2012b_exper_M->Timing.clockTickH0;
  }

  inverted_pendulum_2012b_exper_M->Timing.t[0] =
    inverted_pendulum_2012b_exper_M->Timing.clockTick0 *
    inverted_pendulum_2012b_exper_M->Timing.stepSize0 +
    inverted_pendulum_2012b_exper_M->Timing.clockTickH0 *
    inverted_pendulum_2012b_exper_M->Timing.stepSize0 * 4294967296.0;
  if (inverted_pendulum_2012b_exper_M->Timing.TaskCounters.TID[1] == 0) {
    /* Update absolute timer for sample time: [0.25s, 0.0s] */
    /* The "clockTick1" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick1"
     * and "Timing.stepSize1". Size of "clockTick1" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick1 and the high bits
     * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++inverted_pendulum_2012b_exper_M->Timing.clockTick1)) {
      ++inverted_pendulum_2012b_exper_M->Timing.clockTickH1;
    }

    inverted_pendulum_2012b_exper_M->Timing.t[1] =
      inverted_pendulum_2012b_exper_M->Timing.clockTick1 *
      inverted_pendulum_2012b_exper_M->Timing.stepSize1 +
      inverted_pendulum_2012b_exper_M->Timing.clockTickH1 *
      inverted_pendulum_2012b_exper_M->Timing.stepSize1 * 4294967296.0;
  }

  rate_scheduler();
}

/* Model initialize function */
void inverted_pendulum_2012b_exper_initialize(void)
{
  /* S-Function Block: <S2>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE)
        inverted_pendulum_2012b_exper_P.AnalogOutput_RangeMode;
      parm.rangeidx = inverted_pendulum_2012b_exper_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &inverted_pendulum_2012b_exper_P.AnalogOutput_Channels,
                     &inverted_pendulum_2012b_exper_P.AnalogOutput_InitialValue,
                     &parm);
    }
  }

  /* InitializeConditions for Delay: '<Root>/Delay' */
  inverted_pendulum_2012b_exper_DWork.Delay_DSTATE[0] =
    inverted_pendulum_2012b_exper_P.Delay_InitialCondition;
  inverted_pendulum_2012b_exper_DWork.Delay_DSTATE[1] =
    inverted_pendulum_2012b_exper_P.Delay_InitialCondition;

  /* InitializeConditions for Delay: '<Root>/Delay1' */
  inverted_pendulum_2012b_exper_DWork.Delay1_DSTATE[0] =
    inverted_pendulum_2012b_exper_P.Delay1_InitialCondition;
  inverted_pendulum_2012b_exper_DWork.Delay1_DSTATE[1] =
    inverted_pendulum_2012b_exper_P.Delay1_InitialCondition;

  /* Enable for Sin: '<Root>/Sine Wave' */
  inverted_pendulum_2012b_exper_DWork.systemEnable = 1;
}

/* Model terminate function */
void inverted_pendulum_2012b_exper_terminate(void)
{
  /* S-Function Block: <S2>/Analog Output */
  {
    {
      ANALOGIOPARM parm;
      parm.mode = (RANGEMODE)
        inverted_pendulum_2012b_exper_P.AnalogOutput_RangeMode;
      parm.rangeidx = inverted_pendulum_2012b_exper_P.AnalogOutput_VoltRange;
      RTBIO_DriverIO(0, ANALOGOUTPUT, IOWRITE, 1,
                     &inverted_pendulum_2012b_exper_P.AnalogOutput_Channels,
                     &inverted_pendulum_2012b_exper_P.AnalogOutput_FinalValue,
                     &parm);
    }
  }
}

/*========================================================================*
 * Start of Classic call interface                                        *
 *========================================================================*/
void MdlOutputs(int_T tid)
{
  inverted_pendulum_2012b_exper_output();

  /* tid is required for a uniform function interface.
   * Argument tid is not used in the function. */
  UNUSED_PARAMETER(tid);
}

void MdlUpdate(int_T tid)
{
  inverted_pendulum_2012b_exper_update();

  /* tid is required for a uniform function interface.
   * Argument tid is not used in the function. */
  UNUSED_PARAMETER(tid);
}

void MdlInitializeSizes(void)
{
}

void MdlInitializeSampleTimes(void)
{
}

void MdlInitialize(void)
{
}

void MdlStart(void)
{
  inverted_pendulum_2012b_exper_initialize();
}

void MdlTerminate(void)
{
  inverted_pendulum_2012b_exper_terminate();
}

RT_MODEL_inverted_pendulum_2012b_exper *inverted_pendulum_2012b_exper(void)
{
  /* Registration code */

  /* initialize non-finites */
  rt_InitInfAndNaN(sizeof(real_T));

  /* initialize real-time model */
  (void) memset((void *)inverted_pendulum_2012b_exper_M, 0,
                sizeof(RT_MODEL_inverted_pendulum_2012b_exper));

  /* Initialize timing info */
  {
    int_T *mdlTsMap =
      inverted_pendulum_2012b_exper_M->Timing.sampleTimeTaskIDArray;
    mdlTsMap[0] = 0;
    mdlTsMap[1] = 1;
    inverted_pendulum_2012b_exper_M->Timing.sampleTimeTaskIDPtr = (&mdlTsMap[0]);
    inverted_pendulum_2012b_exper_M->Timing.sampleTimes =
      (&inverted_pendulum_2012b_exper_M->Timing.sampleTimesArray[0]);
    inverted_pendulum_2012b_exper_M->Timing.offsetTimes =
      (&inverted_pendulum_2012b_exper_M->Timing.offsetTimesArray[0]);

    /* task periods */
    inverted_pendulum_2012b_exper_M->Timing.sampleTimes[0] = (0.005);
    inverted_pendulum_2012b_exper_M->Timing.sampleTimes[1] = (0.25);

    /* task offsets */
    inverted_pendulum_2012b_exper_M->Timing.offsetTimes[0] = (0.0);
    inverted_pendulum_2012b_exper_M->Timing.offsetTimes[1] = (0.0);
  }

  rtmSetTPtr(inverted_pendulum_2012b_exper_M,
             &inverted_pendulum_2012b_exper_M->Timing.tArray[0]);

  {
    int_T *mdlSampleHits =
      inverted_pendulum_2012b_exper_M->Timing.sampleHitArray;
    mdlSampleHits[0] = 1;
    mdlSampleHits[1] = 1;
    inverted_pendulum_2012b_exper_M->Timing.sampleHits = (&mdlSampleHits[0]);
  }

  rtmSetTFinal(inverted_pendulum_2012b_exper_M, -1);
  inverted_pendulum_2012b_exper_M->Timing.stepSize0 = 0.005;
  inverted_pendulum_2012b_exper_M->Timing.stepSize1 = 0.25;

  /* External mode info */
  inverted_pendulum_2012b_exper_M->Sizes.checksums[0] = (1491884623U);
  inverted_pendulum_2012b_exper_M->Sizes.checksums[1] = (507047839U);
  inverted_pendulum_2012b_exper_M->Sizes.checksums[2] = (456312358U);
  inverted_pendulum_2012b_exper_M->Sizes.checksums[3] = (3248302337U);

  {
    static const sysRanDType rtAlwaysEnabled = SUBSYS_RAN_BC_ENABLE;
    static RTWExtModeInfo rt_ExtModeInfo;
    static const sysRanDType *systemRan[1];
    inverted_pendulum_2012b_exper_M->extModeInfo = (&rt_ExtModeInfo);
    rteiSetSubSystemActiveVectorAddresses(&rt_ExtModeInfo, systemRan);
    systemRan[0] = &rtAlwaysEnabled;
    rteiSetModelMappingInfoPtr(inverted_pendulum_2012b_exper_M->extModeInfo,
      &inverted_pendulum_2012b_exper_M->SpecialInfo.mappingInfo);
    rteiSetChecksumsPtr(inverted_pendulum_2012b_exper_M->extModeInfo,
                        inverted_pendulum_2012b_exper_M->Sizes.checksums);
    rteiSetTPtr(inverted_pendulum_2012b_exper_M->extModeInfo, rtmGetTPtr
                (inverted_pendulum_2012b_exper_M));
  }

  inverted_pendulum_2012b_exper_M->solverInfoPtr =
    (&inverted_pendulum_2012b_exper_M->solverInfo);
  inverted_pendulum_2012b_exper_M->Timing.stepSize = (0.005);
  rtsiSetFixedStepSize(&inverted_pendulum_2012b_exper_M->solverInfo, 0.005);
  rtsiSetSolverMode(&inverted_pendulum_2012b_exper_M->solverInfo,
                    SOLVER_MODE_SINGLETASKING);

  /* block I/O */
  inverted_pendulum_2012b_exper_M->ModelData.blockIO = ((void *)
    &inverted_pendulum_2012b_exper_B);
  (void) memset(((void *) &inverted_pendulum_2012b_exper_B), 0,
                sizeof(BlockIO_inverted_pendulum_2012b_exper));

  /* parameters */
  inverted_pendulum_2012b_exper_M->ModelData.defaultParam = ((real_T *)
    &inverted_pendulum_2012b_exper_P);

  /* states (dwork) */
  inverted_pendulum_2012b_exper_M->Work.dwork = ((void *)
    &inverted_pendulum_2012b_exper_DWork);
  (void) memset((void *)&inverted_pendulum_2012b_exper_DWork, 0,
                sizeof(D_Work_inverted_pendulum_2012b_exper));

  /* data type transition information */
  {
    static DataTypeTransInfo dtInfo;
    (void) memset((char_T *) &dtInfo, 0,
                  sizeof(dtInfo));
    inverted_pendulum_2012b_exper_M->SpecialInfo.mappingInfo = (&dtInfo);
    dtInfo.numDataTypes = 14;
    dtInfo.dataTypeSizes = &rtDataTypeSizes[0];
    dtInfo.dataTypeNames = &rtDataTypeNames[0];

    /* Block I/O transition table */
    dtInfo.B = &rtBTransTable;

    /* Parameters transition table */
    dtInfo.P = &rtPTransTable;
  }

  /* Initialize Sizes */
  inverted_pendulum_2012b_exper_M->Sizes.numContStates = (0);/* Number of continuous states */
  inverted_pendulum_2012b_exper_M->Sizes.numY = (0);/* Number of model outputs */
  inverted_pendulum_2012b_exper_M->Sizes.numU = (0);/* Number of model inputs */
  inverted_pendulum_2012b_exper_M->Sizes.sysDirFeedThru = (0);/* The model is not direct feedthrough */
  inverted_pendulum_2012b_exper_M->Sizes.numSampTimes = (2);/* Number of sample times */
  inverted_pendulum_2012b_exper_M->Sizes.numBlocks = (37);/* Number of blocks */
  inverted_pendulum_2012b_exper_M->Sizes.numBlockIO = (8);/* Number of block outputs */
  inverted_pendulum_2012b_exper_M->Sizes.numBlockPrms = (49);/* Sum of parameter "widths" */
  return inverted_pendulum_2012b_exper_M;
}

/*========================================================================*
 * End of Classic call interface                                          *
 *========================================================================*/
