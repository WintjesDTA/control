/*
 * inverted_pendulum_2012b_exper_data.c
 *
 * Code generation for model "inverted_pendulum_2012b_exper".
 *
 * Model version              : 1.60
 * Simulink Coder version : 8.3 (R2012b) 20-Jul-2012
 * C source code generated on : Wed May 24 16:26:56 2017
 *
 * Target selection: rtwin.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Generic->32-bit x86 compatible
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */
#include "inverted_pendulum_2012b_exper.h"
#include "inverted_pendulum_2012b_exper_private.h"

/* Block parameters (auto storage) */
Parameters_inverted_pendulum_2012b_exper inverted_pendulum_2012b_exper_P = {
  -0.65,                               /* Expression: offset_x
                                        * Referenced by: '<S1>/Offset_x (volts)'
                                        */
  10.0,                                /* Expression: MaxMissedTicks
                                        * Referenced by: '<S1>/Analog Input'
                                        */
  0.0,                                 /* Expression: YieldWhenWaiting
                                        * Referenced by: '<S1>/Analog Input'
                                        */
  0.1033,                              /* Expression: v2m
                                        * Referenced by: '<S1>/Convertion actor'
                                        */
  0.05,                                /* Expression: offset_alfa
                                        * Referenced by: '<S1>/Offset_alfa (volt)'
                                        */
  0.2482,                              /* Expression: v2r
                                        * Referenced by: '<S1>/Convertion '
                                        */
  0.015707963267948967,                /* Expression: wc*Ts
                                        * Referenced by: '<Root>/Gain'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Delay'
                                        */
  0.984534960996653,                   /* Expression: 1/(1+wc*Ts)
                                        * Referenced by: '<Root>/Gain1'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Delay1'
                                        */
  200.0,                               /* Expression: 1/Ts
                                        * Referenced by: '<Root>/Gain3'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Off1'
                                        */
  10.0,                                /* Expression: 10
                                        * Referenced by: '<Root>/Step'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Step'
                                        */
  0.2,                                 /* Expression: .2
                                        * Referenced by: '<Root>/Step'
                                        */
  0.2,                                 /* Expression: .2
                                        * Referenced by: '<Root>/Sine Wave'
                                        */
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Sine Wave'
                                        */
  1.0,                                 /* Expression: 1
                                        * Referenced by: '<Root>/Sine Wave'
                                        */
  0.0049999791666927081,               /* Computed Parameter: SineWave_Hsin
                                        * Referenced by: '<Root>/Sine Wave'
                                        */
  0.99998750002604164,                 /* Computed Parameter: SineWave_HCos
                                        * Referenced by: '<Root>/Sine Wave'
                                        */
  -0.0049999791666927081,              /* Computed Parameter: SineWave_PSin
                                        * Referenced by: '<Root>/Sine Wave'
                                        */
  0.99998750002604164,                 /* Computed Parameter: SineWave_PCos
                                        * Referenced by: '<Root>/Sine Wave'
                                        */

  /*  Expression: -1*K_lqr
   * Referenced by: '<Root>/Gain2'
   */
  { 12.90994448736793, 146.04762568564075, 41.812329049131236,
    28.256688290616488 },
  0.0,                                 /* Expression: 0
                                        * Referenced by: '<Root>/Off'
                                        */
  5.0,                                 /* Expression: 5
                                        * Referenced by: '<S2>/-5v to 5v'
                                        */
  -5.0,                                /* Expression: -5
                                        * Referenced by: '<S2>/-5v to 5v'
                                        */
  -1.0,                                /* Expression: -1
                                        * Referenced by: '<S2>/Gain'
                                        */
  10.0,                                /* Expression: MaxMissedTicks
                                        * Referenced by: '<S2>/Analog Output'
                                        */
  0.0,                                 /* Expression: YieldWhenWaiting
                                        * Referenced by: '<S2>/Analog Output'
                                        */
  0.0,                                 /* Expression: InitialValue
                                        * Referenced by: '<S2>/Analog Output'
                                        */
  0.0,                                 /* Expression: FinalValue
                                        * Referenced by: '<S2>/Analog Output'
                                        */
  5.0,                                 /* Expression: 5
                                        * Referenced by: '<Root>/Saturation'
                                        */
  -5.0,                                /* Expression: -5
                                        * Referenced by: '<Root>/Saturation'
                                        */
  57.295779513082323,                  /* Expression: 180/pi
                                        * Referenced by: '<S3>/Gain'
                                        */

  /*  Expression: Channels
   * Referenced by: '<S1>/Analog Input'
   */
  { 0, 1 },
  0,                                   /* Expression: RangeMode
                                        * Referenced by: '<S1>/Analog Input'
                                        */
  0,                                   /* Expression: VoltRange
                                        * Referenced by: '<S1>/Analog Input'
                                        */
  0,                                   /* Expression: Channels
                                        * Referenced by: '<S2>/Analog Output'
                                        */
  0,                                   /* Expression: RangeMode
                                        * Referenced by: '<S2>/Analog Output'
                                        */
  0,                                   /* Expression: VoltRange
                                        * Referenced by: '<S2>/Analog Output'
                                        */
  1U,                                  /* Computed Parameter: Delay_DelayLength
                                        * Referenced by: '<Root>/Delay'
                                        */
  1U,                                  /* Computed Parameter: Delay1_DelayLength
                                        * Referenced by: '<Root>/Delay1'
                                        */
  1U,                                  /* Computed Parameter: ManualSwitch_CurrentSetting
                                        * Referenced by: '<Root>/Manual Switch'
                                        */
  1U,                                  /* Computed Parameter: ManualSwitch1_CurrentSetting
                                        * Referenced by: '<Root>/Manual Switch1'
                                        */
  1U                                   /* Computed Parameter: Switch_CurrentSetting
                                        * Referenced by: '<Root>/Switch  '
                                        */
};
