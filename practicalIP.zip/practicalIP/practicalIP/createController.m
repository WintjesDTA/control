Rm = 2.6; %Ohm
Km = 0.00767; %Nm/A
Kb = 0.00767; %V/rad/s
Kg = 3.7;
M = 0.455;
l = 0.305;
m = 0.210;
r = 0.00635;
g = 9.8066;
Ts = 0.005;
wc = 2*2*pi;

A = [0,0,1,0;
    0,0,0,1;
    0,-m*g/M,-Kg^2*Km*Kb/(M*Rm*r^2),0;
     0,(M+m)*g/(M*l),Kg^2*Km*Kb/(M*Rm*r^2*l),0];
B = [0;
    0;
    Km*Kg/(M*Rm*r);
    -Km*Kg/(r*Rm*M*l)];
C = eye(4);
D = [0;0;0;0];


Q = [1, 0, 0, 0;
    0, 4, 0, 0;
    0, 0, 4, 0;
    0, 0, 0, 0];
IPsys = ss(A,B,C,D);
R = 0.004;
K_lqr = lqr(IPsys, Q, R, 0);
K_lqr
x0= [0;0;0;0];
xdesired = .1;

%% QLR check matlab
sysIPfb = ss(A-B*K_lqr,B,C,D);
step(sysIPfb)
figure;
impulse(sysIPfb)

%% Plot states and output simulation1
close all
figure
hold on;
plot(states(:,1), states(:,2),'r');
plot(states(:,1), states(:,3),'g');
plot(states(:,1), states(:,4),'k');
plot(states(:,1), states(:,5));
xlabel('time in seconds'); ylabel('card position');
title('Position plot');
legend('x', 'theta', 'xdot', 'thetadot');
saveas(gcf, strcat('state',num2str(Q(1,1)),num2str(Q(2,2)),num2str(Q(3,3)),num2str(Q(4,4))),'jpg');


figure
plot(input(:,1), input(:,2));
xlabel('time in seconds'); ylabel('input in volts');
saveas(gcf, strcat('input',num2str(Q(1,1)),num2str(Q(2,2)),num2str(Q(3,3)),num2str(Q(4,4))),'jpg')
title('Input plot');

%% Plot states and output simulation2
close all
figure
hold on;
plot(states(:,1), states(:,2),'r');
plot(states(:,1), states(:,3),'g');
plot(states(:,1), states(:,4),'k');
plot(states(:,1), states(:,5));
xlabel('time in seconds'); ylabel('card position');
title('Position plot');
legend('x', 'theta', 'xdot', 'thetadot');
saveas(gcf, strcat('state2',num2str(Q(1,1)),num2str(Q(2,2)),num2str(Q(3,3)),num2str(Q(4,4)),num2str(ceil(wc))),'jpg');


figure
plot(input(:,1), input(:,2));
xlabel('time in seconds'); ylabel('input in volts');
saveas(gcf, strcat('input2',num2str(Q(1,1)),num2str(Q(2,2)),num2str(Q(3,3)),num2str(Q(4,4)),num2str(ceil(wc))),'jpg')
title('Input plot');

%% Plot states and output practicum
experiment = 'step';
plot(states.time, states.signals.values(:,1));
xlabel('time in seconds'); ylabel('card position');
saveas(gcf, strcat('position',experiment,num2str(Q(1,1)),num2str(Q(2,2)),num2str(Q(3,3)),num2str(Q(4,4))),'jpg');

plot(input.time, input.signals.values(:,1));
xlabel('time in seconds'); ylabel('card poistion');
saveas(gcf, strcat('inputstep',experiment,num2str(Q(1,1)),num2str(Q(2,2)),num2str(Q(3,3)),num2str(Q(4,4))),'jpg')