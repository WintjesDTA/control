load('ex2_data.mat');
lamda = eig(A) %Get the poles of the system.

%% find the matrix Gamma
alpha = real(lambda(2));
beta = imag(lambda(2));
lamda1 = real(lambda(1));
gamma = [alpha, beta, 0;
        -beta, alpha, 0;
        0, 0, lambda1];
K1 = place(A,B2,[-3+1i,-3-1i, -1]);
K2 = place(A,B2,[-10+2.5*1i,-10-2.5*1i, -12.1]);
eig(A-B2*K1) %works
eig(A-B2*K2) %works

%% Get impulse responses
hold on;
sys = ss(A-B2*K1,B2,C2,0);
impulse(sys,sys2);
%sys2 = ss(A-B2*K2,B2,C2,0);
%impulse(sys2);
legend('system1','system2')